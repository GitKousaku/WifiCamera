#define VERSION "No version"
